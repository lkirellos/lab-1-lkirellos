# Lab 1 Code Template

Follow [lab 1](https://github.com/ece362-purdue/labs/tree/main/lab1-gpio/README.md) to fill out the main.c file and complete this lab.

When you are submitting to Gradescope, you'll submit this repository on GitHub.
